package com.design.model.decorator.demo2noodle;

import com.design.model.decorator.demo2noodle.noodleCondiment.Beef;
import com.design.model.decorator.demo2noodle.noodleCondiment.Vegetable;
import com.design.model.decorator.demo2noodle.noodleType.RamenNoodle;
import com.design.model.decorator.demo2noodle.noodleType.SlicedNoodles;

public class NoodleTest {

	public static void main(String[] args) {
		
		Noodle ramen = new RamenNoodle();
		ramen = new Vegetable(ramen);
		ramen = new Beef(ramen);
		ramen = new Vegetable(ramen);
		System.out.println(ramen.getName()+" 共计："+ramen.cost());
		
		Noodle noodle = new SlicedNoodles();
		System.out.println(noodle.getName() + "  $ is " + noodle.cost());

		Noodle noodle1 = new SlicedNoodles();
		noodle1 = new Vegetable(noodle1);
		noodle1 = new Vegetable(noodle1);
		noodle1 = new Beef(noodle1);
		System.out.println(noodle1.getName()+"  "+noodle1.cost());

	}

}
