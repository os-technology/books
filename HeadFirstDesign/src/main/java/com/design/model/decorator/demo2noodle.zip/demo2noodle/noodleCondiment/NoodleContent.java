package com.design.model.decorator.demo2noodle.noodleCondiment;

import com.design.model.decorator.demo2noodle.Noodle;

/**
 * 面条添加的内容
 * 
 * @author shui
 *
 */
public abstract class NoodleContent extends Noodle {

	public abstract String getName();

	public abstract double cost();
}
