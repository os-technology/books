package com.design.model.decorator.demo2noodle.noodleCondiment;

import com.design.model.decorator.demo2noodle.Noodle;

public class Beef extends NoodleContent {
	Noodle noodle;
	public Beef(Noodle noodle){
		this.noodle = noodle;
	}
	
	@Override
	public String getName() {
		return noodle.getName()+",添加牛肉";
	}

	@Override
	public double cost() {
		
		return noodle.cost()+3;
	}

}
