package com.design.model.decorator.demo2noodle.noodleType;

import com.design.model.decorator.demo2noodle.Noodle;

public class SlicedNoodles extends Noodle {

	String name = "这是刀削面";

	public String getName() {
		return name;
	}

	@Override
	public double cost() {
		return 10;
	}

}
