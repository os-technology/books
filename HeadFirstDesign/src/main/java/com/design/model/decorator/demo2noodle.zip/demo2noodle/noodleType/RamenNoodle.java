package com.design.model.decorator.demo2noodle.noodleType;

import com.design.model.decorator.demo2noodle.Noodle;

public class RamenNoodle extends Noodle {
	String name = "这是拉面";

	public String getName() {
		return name;
	}

	@Override
	public double cost() {

		return 8;
	}

}
